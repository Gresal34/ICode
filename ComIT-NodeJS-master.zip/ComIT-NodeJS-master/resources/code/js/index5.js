const name = 'nico';
const age = 39;
const myFunction = function() {
  console.log('Ohhh you guys called myFunction function');
}
const log = function(message) {
  console.log(message);
}

console.log(typeof myFunction);

myFunction();

log('Ohhh you guys called the log function');