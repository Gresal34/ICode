function add(firstNumber, secondNumber, thirdNumber) {
  return firstNumber + secondNumber + thirdNumber;
}

const firstValue = 2;
const secondVaue = 3;
const thirdValue = 5;

const result = add(2, 3, 5);
const result2 = add(22, 31, 54);
const resultWithVariables = add(firstValue, secondVaue, thirdValue);

console.log(result);
console.log(result2);
console.log(resultWithVariables);
