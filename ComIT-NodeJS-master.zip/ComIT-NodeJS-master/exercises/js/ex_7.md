# Exercise 7

* Create a new index7.js file
* Copy and paste the code from ex_6
* Refactor your code to use **let** instead of **var**