# Exercise 5

* Create a new index5.js file
* Copy and paste the code from ex_4
* Show each variable value using `console.log()`