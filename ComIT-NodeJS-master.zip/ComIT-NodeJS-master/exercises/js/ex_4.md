# Exercise 4

* Create a new index4.js file
* Declare the following values and assign a value (one per line) 
  * First name / Your first name (string)
  * Last name / Your last name (string)
  * Age /  Your age (number)
  * Date of birth / Your date of birth (string, format mm/dd/yyyy)
  * Address / Your address (string)