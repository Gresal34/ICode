# Exercise 9

* Create a new index9.js file
* Declare a constant variable with the name first name and assign your name
* In the following line try to change the variable value to 'Pablo'
* Execute the program and see what happens
