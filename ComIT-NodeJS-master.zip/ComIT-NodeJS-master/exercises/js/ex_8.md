# Exercise 8

* Create a new index8.js file
* Copy and paste the code from ex_7
* Refactor your code to use **const** instead of **let**