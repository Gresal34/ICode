# Exercise 6

* Create a new index6.js file
* Copy and paste the code from ex_5
* Refactor the code to show the variable name and value using `console.log()`