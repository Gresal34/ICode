# Exercise 2

* Create a new index2.js file
* Declare the following values: 
  * First name
  * Last name
  * Age
  * Date of birth
  * Address
* Assign a value to each variable using the right variable name
  * Your first name (string)
  * Your last name (string)
  * Your age (number)
  * Your date of birth (string, format mm/dd/yyyy)
  * Your address (string)

* **TIP:** Use single or double quotes around the text for strings