# Exercise 1

* Create a new index1.js file
* Declare the following variables:
  * First name
  * Last name
  * Age
  * Address
  * Date of birth (using camel case)