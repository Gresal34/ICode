# Exercise 8

* Create the following folder/file structure:
```
/ex_8
  |-- index.html
```

## index.html
* Copy and paste the code from the previous exercise
* Refactor the code to math the new requirements:
* Now we need to keep track of how many numbers the user input
* Once the user doesn't want to add any more numbers show the following message:
```
The final result is: %result%
The user input %numbers% numbers
The average is: %average%
```