# Exercise 2

* Create the following folder/file structure:
```
/ex_2
  |-- index.html
  |-- script.js
```

## index.html
* Create a basic HTML document
* Create a script tag on the document head element
* Add the script.js file to the document

## script.js
* Using the console show odd numbers from 1 to 1000