# Exercise 9

* Create the following folder/file structure:
```
/ex_9
  |-- index.html
```

## index.html
* Create a basic HTML document
* Create a script tag on the document head element
* Ask the user to input a complete URL
* Redirect the user to the new location