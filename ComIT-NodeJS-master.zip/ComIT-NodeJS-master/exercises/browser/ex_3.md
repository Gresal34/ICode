# Exercise 3

* Create the following folder/file structure:
```
/ex_3
  |-- index.html
```

## index.html
* Create a basic HTML document
* Create a script tag on the document head element
* Show the user the following message `using the alert`
* Open the browser and see the final result