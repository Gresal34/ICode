# Exercise 4

* Create the following folder/file structure:
```
/ex_4
  |-- index.html
```

## index.html
* Create a basic HTML document
* Create a script tag on the document head element
* Using prompt method ask the user to input his firstname
* Using prompt method ask the user to input his lastname
* Show the following message using the alert method

```
Welcome %firstname% %lastname% to JavaScript client side!!!
```
