# Exercise 1

* Create the following folder/file structure:
```
/ex_1
  |-- index.js
```

## Todo
* Init an NPM project inside the ex_1 folder
* Use ex_1 as project name
* Configure the project so it runs index.js when we run `npm start` command

## index.js

* Once we start the project it will otuput the following message:
```
Running my first script!!
```