# Exercise 2

* Create the following folder/file structure:
```
/ex_2
  |-- index.js
```

## Todo
* Init an NPM project inside the ex_2 folder
* Use ex_2 as project name
* Install express as project dependency
* Add npm start script so it runs the index.js file

## index.js
* Show the `express` object as output