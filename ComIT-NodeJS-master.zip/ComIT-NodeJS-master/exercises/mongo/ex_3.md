# Exercise 3

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Create a query cursor using `db.superheroes.find()`
* Call `cursor.next()` ten times
* On each call ask if there's more documents using `cursor.hasNext()`
