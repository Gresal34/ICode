# Exercise 8

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Update the document with Hulk as name and set the power to 80 as he didn't fight on Avengers: Infinity War
* Find any document that you like and update it using `ObjectId()`
* Then find the same document using the same `ObjectId()`
