# Exercise 6

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Query all superheroes documents and show a pretty result
