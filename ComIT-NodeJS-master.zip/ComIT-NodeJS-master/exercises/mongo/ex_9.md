# Exercise 8

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Find the document with name IRON MAN
* Delete the document using _id and `ObjectId()`