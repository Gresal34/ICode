# Exercise 1

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell
* Create a comics database
* Create the superheroes collection
* Insert the following documents one by one
```json
{ "name": "SPIDER-MAN", "image": "spiderman.jpg" }
{ "name": "CAPTAIN MARVEL", "image": "captainmarvel.jpg" }
{ "name": "HULK", "image": "hulk.jpg" }
```
* Show the available databases
* Show the aviablables collections for the comics database
* Disconect from MongoDB shell
* Connect to MongoDB shell again using the comic database as initial selected one
