# Exercise 7

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Query a document with name DAREDEVIL and image daredevil.jpg
