# Exercise 2

* Start MongoDB server
* Connect to MongoDB server using MongoDB shell and 
* Select comics database
* Query all the superheroes inserted documents
* Query the superheros by name:
  * DAREDEVIL
  * THOR
* Query superheros by image:
  * ironman.jpg
  * captainmarvel.jpg